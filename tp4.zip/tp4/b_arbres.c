#include "b_arbres.h"
#include<stdio.h>
#include<stdlib.h> 
#define MAXELTS 2000

Noeud * b_arbre_create(){
  Noeud * res = (Noeud *) malloc( sizeof(Noeud) );
  Noeud * tabFils = (Noeud *) malloc( sizeof(Noeud) );
  res->pere = (Noeud *) malloc( sizeof(Noeud) );
  res->isFeuille = 0;
  res->noNoeud = 5;
  return res;
}



    /**
     ** Noeud * recherche(int v, Noeud *noeud)
     ** recherche la valeur v dans l'arbre r
     ** retourne un pointeur sur le noeud qui contient v, NULL sinon
     */
Noeud* recherche(int v, Noeud* noeud)
{
        Noeud* result = NULL;
        if (noeud != NULL) {
            int i = 1;
            int nbElt = noeud->tabVal[0];
            while ( (i <= nbElt) && (v > noeud->tabVal[i])) i++;
            if (v == noeud->tabVal[i])
                result = noeud;
            else // chercher dans le fils qui contient des valeurs < ou = à v
                result = recherche(v, noeud->tabFils[i-1]);
}
        // si on n'a pas trouve
        return result;
    }


// Insertion d’une valeur dans un noeud feuille
   
 
    /**
     ** int insererSimple(int v, Noeud* noeud)
     ** insere la valeur v dans le tableau du noeud
     ** retourne la position de v, ou 0 si echec
     **/
    int insererSimple(int v, Noeud* noeud)
    {
        int result = 0;
        int i=0;
        if (noeud != NULL)
        {
            i = noeud->tabVal[0] + 1;
            if (i < MAXELTS)
            {
                while ( (i>1) && (v < noeud->tabVal[i-1]) )
                {
                    noeud->tabVal[i] = noeud->tabVal[i-1];
                    i --;
                }
                noeud->tabVal[i] = v;
                noeud->tabVal[0] += 1;
                result= i;
            }
        }
        return result;
    }

// Suppression de valeurs dans un noeud

    /**
     ** void oterSuiteElts(Noeud *noeud, int debut)
     ** retire les elements à partir de la position debut jusqu'à la fin du tableau
     **/
    void oterSuiteElts(Noeud *noeud, int debut)
    {
        int nbElts = noeud->tabVal[0];
        if (nbElts>0)
        {
            int i=0;
            for (i=debut; i<MAXELTS; i++)
            {
                noeud->tabVal[i] = 0;
                noeud->tabFils[i] = NULL;
            }
            noeud->tabVal[0] = debut-1;
        }
    }

// Suppression de la première valeur d’un noeud
/**
 ** void oterTete(Noeud *noeud)
 ** retire l'element de tete du tableau
 **/
void oterTete(Noeud *noeud)
{
    int nbElts = noeud->tabVal[0];
    if (nbElts>0)
    {
        int i=0;
        for (i=1; i<nbElts; i++)
        {
            noeud->tabVal[i] = noeud->tabVal[i+1];
        }
        noeud->tabVal[nbElts] = 0;
        noeud->tabVal[0] -= 1;
       
    }
}








