/* ajouter d'une clé dans un avl */ 
(arbre,int) AJOUTER(element x, arbre A) {
	if (A == NULL) {
		créer un nœud A;  
		A->g = NULL;  A->d = NULL;
 		A->elt = x;  A->bal = 0;return (A,1);
	} else if (x == A->elt)
		return (A,0);
	else if (x > A->elt)
		(A->d,h) = AJOUTER(x,A->d); 
	else
		(A->g,h) = AJOUTER(x,A->g); 
		h = -h;
	if (h == 0)
		return (A,0);
	else 
		A->bal = A->bal + h;
		A = EQUILIBRER(A);
	if (A->bal == 0) 
		return (A,0); 
	else 
		return (A,1);
}
/* supprimer d'une clé dans un avl */ 
(arbre,int) ENLEVER(element x, arbre A) {
	if (A == NULL)
		return (A,0);
	else if (x > A->elt)
		(A->d,h) = ENLEVER(x,A->d);
	else if (x < A->elt)
		(A->g,h) = ENLEVER(x,A->g);
		 h = -h;
	else if (A->g == NULL) {
	/* free */ 
		return (A->d,-1);
	}
       else if (A->d == NULL) {
       /* free */ 
              return (A->g,-1);
       }
      else {
            A->elt = min(A->d);
           (A->d,h) = OTERMIN(A->d);
       }
    if (h == 0)
      return (A,0);
    else {
     A->bal = A->bal + h;A = EQUILIBRER(A);
   if (A->bal == 0) return (A,-1);
   else return (A,0);
   } 
}

(arbre,int) rechercher(element x, arbre A) { 
	if (A== NULL) || (x=A->elt) 
	   return A;
	if (x< A->elt) 
	  return rechercher (x,A->g);
	else 
	  return rechercher (x,A->d);

