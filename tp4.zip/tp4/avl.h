#ifndef __AVL_H
#define __AVL_H
#include <stddef.h>

struct NOEUD {

	int elt ;
	deuxbits bal ; /* compris entre –1 et +1 *//* -2 et +2 dans la suite */
	struct NOEUD * g, * d ;
} noeud ;
noeud * arbre 

(arbre,int) AJOUTER (element x,arbre A) ;/*rend l’arbre modifié et la différence de hauteur : 0 ou +1 */
(arbre,int) ENLEVER (element x,arbre A) ;/*rend l’arbre modifié et la différence de hauteur : -1 ou 0 */
(arbre,int) rechercher(element x, arbre A);


#endif
