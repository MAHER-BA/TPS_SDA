#ifndef __B_ARBRES_H
#define __B_ARBRES_H
#include <stddef.h>
#define Max 1000

typedef struct _noeud
{
      
	int tabVal[2*Max + 1]; // tabVal[0] contient le nb de valeurs du noeud
        struct _noeud* tabFils[2*Max + 1];  
        struct _noeud* pere;
        int isFeuille;
        int noNoeud; //juste utilisé pour l'affichage, peut être oté
} Noeud;
Noeud * b_arbre_create();
Noeud* recherche(int v, Noeud* noeud);
int insererSimple(int v, Noeud* noeud);
void oterSuiteElts(Noeud *noeud, int debut);
void oterTete(Noeud *noeud);

#endif
